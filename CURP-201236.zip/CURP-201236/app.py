from flask import Flask, render_template, request
from flask import session
import random
import string

app = Flask(__name__)
app.secret_key = 'una_clave_secreta_muy_segura'  # Necesario para usar sesiones

def generar_CURP(nombre, primer_apellido, segundo_apellido, fecha_nacimiento, sexo, entidad_nacimiento):
    # Extraer los primeros caracteres de cada palabra del nombre y apellidos
    nombre_curp = nombre.split()[0].upper()
    apellido_paterno_curp = primer_apellido.upper()
    apellido_materno_curp = segundo_apellido.upper()
    
    # Convertir fecha de nacimiento a formato YYMMDD
    fecha_nacimiento_curp = fecha_nacimiento[8:10] + fecha_nacimiento[3:5] + fecha_nacimiento[0:2]
    
    # Asignar la letra correspondiente al sexo
    letra_sexo = 'M' if sexo.lower() == 'hombre' else 'H'
    
    # Obtener el código de la entidad de nacimiento (en este caso, Chiapas)
    entidad_nacimiento_curp = obtener_codigo_entidad(entidad_nacimiento)
    
    # Calcular la homoclave
    homoclave = buscar_consonante(apellido_paterno_curp[1:]) + buscar_consonante(apellido_materno_curp[1:]) + buscar_consonante(nombre_curp[1:])
    
    # Unir los componentes para formar la CURP
    curp_generada = apellido_paterno_curp[0] + buscar_vocal(apellido_paterno_curp[1:]) + apellido_materno_curp[0] + nombre_curp[0] + fecha_nacimiento_curp + letra_sexo + entidad_nacimiento_curp + homoclave + "00"
    
    return curp_generada

def buscar_vocal(nombre):
    # Función auxiliar para buscar la primera vocal en el nombre
    for letra in nombre:
        if letra in 'AEIOU':
            return letra
    return 'X'  # Si no se encuentra ninguna vocal, devuelve 'X'

def buscar_consonante(nombre):
    # Función auxiliar para buscar la primera consonante en el nombre
    for letra in nombre:
        if letra not in 'AEIOU':
            return letra
    return 'X'  # Si no se encuentra ninguna consonante, devuelve 'X'

def obtener_codigo_entidad(entidad_nacimiento):
    # Mapeo del nombre del estado de Chiapas a su código de entidad correspondiente
    entidades = {
        'CHIAPAS': 'CS'
    }
    
    # Devolver el código de entidad correspondiente si el nombre de la entidad es Chiapas, de lo contrario, devolver 'NE' (no encontrado)
    return entidades.get(entidad_nacimiento.upper(), 'NE')

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'GET':
        # Solo generar un nuevo código de verificación para las solicitudes GET
        verification_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        session['verification_code'] = verification_code
    else:
        # Para las solicitudes POST, usar el código de verificación existente de la sesión
        verification_code = session.get('verification_code', '')

    curp_generada = None
    if request.method == 'POST':
        # Verificar si el código de verificación es correcto
        if 'verification_code' in request.form:
            entered_code = request.form['verification_code']
            if entered_code != verification_code:
                return "El código de verificación es incorrecto. Por favor, inténtalo de nuevo."

    curp_generada = None
    if request.method == 'POST':
        nombre = request.form['nombre']
        primer_apellido = request.form['primer_apellido']
        segundo_apellido = request.form['segundo_apellido']
        fecha_nacimiento = request.form['fecha_nacimiento']
        sexo = request.form['sexo']
        entidad_nacimiento = request.form['entidad_nacimiento']
        
        # Generar la CURP con los datos proporcionados
        curp_generada = generar_CURP(nombre, primer_apellido, segundo_apellido, fecha_nacimiento, sexo, entidad_nacimiento)
    return render_template('index.html', curp_generada=curp_generada, verification_code=verification_code)

if __name__ == '__main__':
    app.run(debug=True)
